
SIMULATEUR TPME - Déploiement

Fichiers inclus:
- simulateur_tpme.py : votre application Streamlit
- requirements.txt : dépendances Python
- README_DEPLOY.md : ce fichier

Options de déploiement (choisissez une):

1) Streamlit Community Cloud (recommandé pour simplicité)
- Crée un compte sur https://streamlit.io/cloud
- Crée un nouveau "app" et connecte un dépôt GitHub (push du projet sur GitHub)
- Dans le dépôt, le fichier simulateur_tpme.py doit être à la racine.
- Streamlit Cloud détecte requirements.txt et installe les dépendances.
- L'URL publique sera fournie par Streamlit Cloud.

2) Hugging Face Spaces (Gratuit, git-based)
- Crée un compte sur https://huggingface.co/
- Crée un Space de type "streamlit"
- Upload des fichiers (simulateur_tpme.py + requirements.txt)
- Le Space démarrera automatiquement.

3) Render
- Crée un dépôt GitHub et pousse les fichiers
- Dans Render, crée un "Web Service" connecté au repo
- Commande de build: `pip install -r requirements.txt`
- Commande de lancement: `streamlit run simulateur_tpme.py --server.port $PORT`
- Render attribuera une URL publique.

Notes:
- Si besoin, j'ajusterai requirements.txt (versions spécifiques).
- Pour deployer pour toi, j'ai préparé un zip téléchargeable. Téléverse-le sur ton service choisi (Streamlit Cloud / HF Spaces / Render) ou donne-moi accès au repo GitHub et je te guide sur les étapes exactes à suivre.

