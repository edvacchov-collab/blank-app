
import streamlit as st

# --- BASES DE DONNÉES (À compléter avec l'Arrêté officiel si besoin) ---
DATA_PROVINCES = {
    # Catégorie B (15%)
    "Al Hoceïma": "B", "Boulemane": "B", "Chefchaouen": "B", "Driouch": "B",
    "Figuig": "B", "Guelmim": "B", "Ifrane": "B", "Jerada": "B",
    "Tan-Tan": "B", "Taounate": "B", "Tata": "B", "Zagora": "B", "Assa-Zag": "B",

    # Catégorie A (10%)
    "Tanger-Assilah": "A", "Fès": "A", "Meknès": "A", "Béni Mellal": "A",
    "Agadir Ida-Outanane": "A", "Marrakech": "A", "Oujda-Angad": "A",

    # Hors Zone (0%)
    "Casablanca": "C", "Rabat": "C", "Mohammedia": "C", "Nouaceur": "C"
}

SECTEURS_PRIORITAIRES = [
    "Industrie",
    "Tourisme & Animation",
    "Industrie Culturelle",
    "Digital & Numérique",
    "Energies Renouvelables",
    "Logistique & Transport",
    "Outsourcing (Offshoring)",
    "Aquaculture"
]

# --- FONCTIONS UTILITAIRES ---
def get_prime_territoriale_taux(province):
    cat = DATA_PROVINCES.get(province, "C")
    if cat == "B": return 15
    if cat == "A": return 10
    return 0

def get_prime_sectorielle_taux(secteur):
    return 10 if secteur in SECTEURS_PRIORITAIRES else 0

def calculer_tpme_final(invest_total, foncier, etudes, emplois, province, secteur, est_feminin=False, bonus_feminin_pct=0):
    """
    Retourne (result_dict, erreur_string)
    result_dict contient : prime, taux, taux_brut, assiette, details, ratio, plafonds
    """
    # --- Validation de base ---
    try:
        invest_total = float(invest_total)
        foncier = float(foncier)
        etudes = float(etudes)
        emplois = float(emplois)
    except Exception:
        return None, "❌ Valeurs numériques invalides."

    if invest_total < 1_000_000 or invest_total >= 50_000_000:
        return None, "❌ Investissement hors seuils (doit être entre 1 000 000 et 50 000 000 DH)."

    if emplois <= 0:
        return None, "❌ Nombre d'emplois doit être >= 1."

    if foncier < 0 or etudes < 0:
        return None, "❌ Les coûts (foncier / études) ne peuvent pas être négatifs."

    # --- Ratio emplois (par million DH investi) ---
    ratio = (emplois / invest_total) * 1_000_000
    seuil_ratio = 1.0 if secteur == "Tourisme & Animation" else 1.5
    if ratio < seuil_ratio:
        return None, f"❌ Ratio d'emplois insuffisant ({ratio:.2f}). Minimum requis : {seuil_ratio}."

    # --- Calcul assiette primable (déductions études & foncier) ---
    base_intermediaire = invest_total

    # Plafond études: min(5% de l'assiette, 500k)
    plafond_etudes = min(base_intermediaire * 0.05, 500_000)
    val_etudes = min(etudes, plafond_etudes)
    deduc_etudes = etudes - val_etudes

    # Foncier: uniquement si secteur éligible (ex: Industrie, Tourisme)
    secteur_eligible_foncier = secteur in ["Industrie", "Tourisme & Animation"]
    if secteur_eligible_foncier:
        plafond_foncier = min(base_intermediaire * 0.20, 5_000_000)
        val_foncier = min(foncier, plafond_foncier)
        deduc_foncier = foncier - val_foncier
    else:
        plafond_foncier = 0
        val_foncier = 0
        deduc_foncier = foncier  # totalité exclue

    assiette_primable = base_intermediaire - deduc_etudes - deduc_foncier
    if assiette_primable <= 0:
        return None, "❌ Après plafonnements, l'assiette primable est nulle ou négative."

    # --- Calcul des taux ---
    taux_cumul = 0
    details = {}

    # Prime Emploi
    t_emploi = 0
    if 2 <= ratio <= 5:
        t_emploi = 5
    elif 5 < ratio <= 10:
        t_emploi = 7
    elif ratio > 10:
        t_emploi = 10
    details['Emploi'] = t_emploi
    taux_cumul += t_emploi

    # Prime Territoriale
    t_terri = get_prime_territoriale_taux(province)
    details['Territoire'] = t_terri
    taux_cumul += t_terri

    # Prime Sectorielle
    t_secteur = get_prime_sectorielle_taux(secteur)
    details['Secteur'] = t_secteur
    taux_cumul += t_secteur

    # Bonus féminin (optionnel; par défaut 0) - selon la politique locale (si applicable)
    t_feminin = bonus_feminin_pct if est_feminin else 0
    if t_feminin:
        details['Femme'] = t_feminin
        taux_cumul += t_feminin

    taux_final = min(taux_cumul, 30)  # Plafond légal
    prime_totale = assiette_primable * (taux_final / 100)

    result = {
        "prime": prime_totale,
        "taux": taux_final,
        "taux_brut": taux_cumul,
        "assiette": assiette_primable,
        "details": details,
        "ratio": ratio,
        "plafonds": {
            "plafond_etudes": plafond_etudes,
            "val_etudes": val_etudes,
            "deduc_etudes": deduc_etudes,
            "plafond_foncier": plafond_foncier,
            "val_foncier": val_foncier,
            "deduc_foncier": deduc_foncier
        }
    }
    return result, None

# --- INTERFACE STREAMLIT ---
st.set_page_config(page_title="Simulateur TPME Maroc", page_icon="🇲🇦")
st.title("🇲🇦 Simulateur TPME - Données Officielles (amélioré)")
st.markdown("Calcul simulé selon les règles générales : plafonds études/foncier, primes emploi/territoire/secteur et plafonnement global. Ajuste les paramètres selon l'Arrêté d'application réel.")

with st.form("simu_form"):
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Le Projet")
        inv_input = st.number_input("Investissement Total HT (DH)", min_value=1_000_000, max_value=49_999_999, step=100_000, value=5_000_000, format="%d")
        emp_input = st.number_input("Emplois Stables (CDI)", min_value=1, max_value=5000, value=10, step=1, format="%d")
        prov_input = st.selectbox("Province / Préfecture du projet", sorted(DATA_PROVINCES.keys()))

    with col2:
        st.subheader("Activité & Coûts")
        secteurs_choices = sorted(SECTEURS_PRIORITAIRES + ["Autre (Commerce, Services non prio...)"])
        sect_input = st.selectbox("Secteur d'activité", secteurs_choices)

        st.caption("Coûts inclus dans l'investissement total (si applicable)")
        foncier_input = st.number_input("Dont coût du Foncier (DH)", min_value=0, value=0, step=10_000, format="%d")
        etudes_input = st.number_input("Dont Frais d'études (DH)", min_value=0, value=0, step=1_000, format="%d")

        st.write("Options avancées")
        est_feminin = st.checkbox("Porteuse de projet (femme) - activer bonus optionnel ?", value=False)
        bonus_feminin_pct = 0
        if est_feminin:
            bonus_feminin_pct = st.number_input("Taux bonus féminin (%) — si applicable par arrêté", min_value=0, max_value=10, value=0, step=1)

    submitted = st.form_submit_button("CALCULER MA PRIME")

if submitted:
    res, err = calculer_tpme_final(inv_input, foncier_input, etudes_input, emp_input, prov_input, sect_input, est_feminin, bonus_feminin_pct)
    if err:
        st.error(err)
    else:
        st.divider()
        c1, c2, c3 = st.columns([2,1,1])
        c1.metric("💰 PRIME TOTALE", f"{res['prime']:,.0f} DH")
        c2.metric("Taux de Financement", f"{res['taux']}%")
        c3.metric("Ratio Emploi (par M DH)", f"{res['ratio']:.2f}")

        st.info(f"**Assiette de calcul :** {res['assiette']:,.0f} DH (Après plafonnements et exclusions)")

        st.write("### 📊 Détail des plafonds et déductions")
        p = res['plafonds']
        st.write(f"- Plafond études : {p['plafond_etudes']:,.0f} DH — Montant retenu : {p['val_etudes']:,.0f} DH — Déduction (exclu) : {p['deduc_etudes']:,.0f} DH")
        st.write(f"- Plafond foncier : {p['plafond_foncier']:,.0f} DH — Montant retenu : {p['val_foncier']:,.0f} DH — Déduction (exclu) : {p['deduc_foncier']:,.0f} DH")

        st.write("### 📈 Composition de votre taux")
        cols_d = st.columns(3)
        cols_d[0].write(f"**Emploi :** {res['details'].get('Emploi',0)}%")
        cols_d[1].write(f"**Territoire ({prov_input}) :** {res['details'].get('Territoire',0)}%")
        cols_d[2].write(f"**Secteur :** {res['details'].get('Secteur',0)}%")
        if res['details'].get('Femme'):
            st.write(f"**Bonus Femme :** {res['details']['Femme']}%")

        if res['taux_brut'] > 30:
            st.warning(f"⚠️ Taux cumulatif théorique = {res['taux_brut']}% — plafonné légalement à 30%.")

        # Option export CSV
        csv_content = "province,secteur,invest_total,assiette,taux_brut,taux_final,prime,ratio\n"
        csv_content += f"{prov_input},{sect_input},{inv_input},{res['assiette']},{res['taux_brut']},{res['taux']},{res['prime']},{res['ratio']:.2f}"
        st.download_button(
            "Télécharger le détail (CSV)",
            data=csv_content,
            file_name="simu_tpme_resultat.csv",
            mime="text/csv"
        )
